<script type="text/javascript" src="<?php echo asset('js/ckfinder/ckfinder.js') ?>"></script>
<script>CKFinder.config( { connectorPath: <?php echo json_encode(route('ckfinder_connector')) ?> } );</script>
